package model.pathfinders;
import utils.UnionFind;
import java.util.*;
import model.Board;

public class PathFinderUF implements PathFinder{
    
    private UnionFind unionF;
    public PathFinder(){
        this.UnionF = new UnionFind(board.getSize());


    }

    @Override
    public boolean hasWinningPath(Board board, Color color){
        
        //UnionFind unionF = new UnionFind(board.getSize())
        for(int i=0; i< board.getSize(); i++){
            for(int j =0; j< this.size; j++){
                if(board.getCell(i,j) != color){
                    return continue;
                }

                int size = board.getSize();
                int currIndex = i*size*j

                if(color == Color.BLUE){
                    if(j == 0){
                        unionF.union(currIndex, unionF.getVirtualLeft());
                    }
                    if( j == size -1){
                        unionF.union(currIndex, unionF.getVirtualRight());
                    }
                }
                else if(color == Color.RED){
                    if(i == 0){
                        unionF.union(currIndex, unionF.getVirtualTop());
                    }
                    if( i == size -1){
                        unionF.union(currIndex, unionF.getVirtualBottom());
                    }
                }

                ArrayList<int[]> neighbors = board.getNeighbors(i,j);
                for(int k=0; k<neighbors.size();k++){
                    int[] neighbor = neighbors.get(i);
                    int neigbRow = neighbor[0];
                    int neigbCol = neighbor[1];

                    if(board.getCell(neigbRow, neigbCol) == color){
                        int neighborIndex = neigbRow*size*neigbCol;
                        unionF.union(currIndex, neighborIndex);
                    }
                    
                }
            }
        }
        if(color == Color.BLUE){
            return unionF.isConnected(unionF.getVirtualLeft(), unionF.getVirtualRight());
        }
        else if(color == Color.RED){
            return unionF.isConnected(unionF.getVirtualTop(), unionF.getVirtualBottom());

        }
        return false;
    }

}